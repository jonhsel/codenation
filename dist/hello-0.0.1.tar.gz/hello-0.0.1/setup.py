from setuptools import setup

setup(
    name = "hello",
    version = "0.0.1",
    description = "Meu novo pacote",
    author = "Jonh Selmo",
    author_email = "jonhselmo.engcomp@gmail.com",
    packages = ["hello"],
    #install_requires = ["numpy"]
)