#!/usr/bin/env python

def main():
    print("Hello Word")

if __name__=='__main__':
    main()